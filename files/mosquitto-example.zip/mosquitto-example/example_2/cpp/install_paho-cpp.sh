#!/bin/bash

sudo apt-get install libssl-dev mosquitto mosquitto-clients libwebsockets-dev libboost-thread-dev build-essential gcc make cmake cmake-gui cmake-curses-gui
git clone https://github.com/eclipse/paho.mqtt.cpp.git
cd paho.mqtt.cpp
mkdir build
cd build
ccmake -DPAHO_BUILD_DOCUMENTATION=FALSE -DPAHO_BUILD_STATIC=TRUE -DPAHO_BUILD_SAMPLES=TRUE -DPAHO_MQTT_C_PATH=../../paho.mqtt.cpp
cd ..
sudo bash install_paho_mqtt_c.sh

exit 0
