# paho-client-MQTTJS-in-web

testing Paho MQTT js web client with a local mqtt web socket server
